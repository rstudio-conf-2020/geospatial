fs::dir_copy("~/git-repos/workshop-r-spatial-exercises/inst/data-raw/", "~/git-repos/rstudio-conf2020-spatial-ex/inst/", overwrite = TRUE)
fs::dir_copy("~/git-repos/workshop-r-spatial-exercises/inst/exercises", "~/git-repos/rstudio-conf2020-spatial-ex/inst/exercises", overwrite = TRUE)
fs::dir_copy("~/git-repos/workshop-r-spatial-exercises/inst/solutions", "~/git-repos/rstudio-conf2020-spatial-ex/inst/solutions", overwrite = TRUE)


fs::dir_copy("~/git-repos/workshop-r-spatial-exercises/man", "~/git-repos/rstudio-conf2020-spatial-ex/man", overwrite = TRUE)
fs::dir_copy("~/git-repos/workshop-r-spatial-exercises/R", "~/git-repos/rstudio-conf2020-spatial-ex/R", overwrite = TRUE)


fs::file_copy("~/git-repos/workshop-r-spatial-exercises/DESCRIPTION", "~/git-repos/rstudio-conf2020-spatial-ex", overwrite = TRUE)
fs::file_copy("~/git-repos/workshop-r-spatial-exercises/LICENSE.md", "~/git-repos/rstudio-conf2020-spatial-ex", overwrite = TRUE)
fs::file_copy("~/git-repos/workshop-r-spatial-exercises/NAMESPACE", "~/git-repos/rstudio-conf2020-spatial-ex", overwrite = TRUE)
fs::file_copy("~/git-repos/workshop-r-spatial-exercises/README.md", "~/git-repos/rstudio-conf2020-spatial-ex", overwrite = TRUE)

# cd ../rstudio-conf2020-spatial-ex/