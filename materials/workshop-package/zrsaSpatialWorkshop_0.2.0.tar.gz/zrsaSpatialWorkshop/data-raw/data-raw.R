# Sorry to anyone viewing this. This script is far from 
# reproducible. Mainly for my own reference.

library(sf)
library(raster)
library(fs)
library(dplyr)


basepath <- "/Volumes/GoogleDrive/My Drive/projects/workshop-r-spatial-slides/big-project-files/gis-data/"
thecrs <- 2908
theproj4 <- CRS(glue::glue("+init=epsg:{thecrs}"))
wgs84 <- CRS("+init=epsg:4236")


tabpath <- "/Volumes/GoogleDrive/My Drive/projects/workshop-r-spatial-slides/big-project-files/gis-data/nyc/raw/Neighborhood Tabulation Areas.geojson"

# Boros simplified
# Reference: 

boro <- st_read(path(basepath, "raw/Borough Boundaries.geojson"))
boro <- st_transform(boro, crs = thecrs)
pryr::object_size(boro) #1.24 MB
boro <- rmapshaper::ms_simplify(boro)
st_geometry(boro) %>% plot()

boro <- mutate(boro,
               shape_area = as.numeric(as.character(shape_area)) * 9.2903e-8,
               shape_leng = as.numeric(as.character(shape_leng)) * 0.0003048) %>% 
  arrange(boro_name) %>% 
  mutate(pop2010 = c(1385108, 2504700, 1585873, 2230722, 468730),
         pop2018 = c(1432123, 2582830, 1628701, 2278906, 476179),
         pop_change = round(100*(pop2018-pop2010)/pop2010, 1))
st_write(boro, path(basepath, "processed/boroughs.gpkg"), delete_layer = TRUE)
st_write(boro, path(basepath, "processed/boroughs.geojson"), delete_layer = TRUE)
st_write(boro, path(basepath, "processed/boroughs.shp"), delete_layer = TRUE)


# Bounding box
# Reference


borobuf <- st_buffer(boro, 328.084)
boro_bbox <- borobuf %>% 
  st_bbox() %>% 
  st_as_sfc() %>% 
  st_sf()

st_geometry(boro_bbox) %>% 
  plot

# Schools
# Reference: 

schools <- st_read(path(basepath, "raw/Public_School_Locations/Public_Schools_Points_2011-2012A.shp"))
schools <- st_transform(schools, crs = thecrs)
schools <- schools %>% 
  filter(SCH_TYPE == "Elementary") %>% 
  dplyr::select(boronum = BORONUM, schoolname = SCHOOLNAME)
pryr::object_size(schools) #1.41 MB
st_geometry(schools) %>% plot()
pryr::object_size(schools) #308kb
st_write(schools, path(basepath, "processed/schools.gpkg"))
st_write(schools, path(basepath, "processed/schools.geojson"))
st_write(schools, path(basepath, "processed/schools.shp"))


# Neighborhoods
# Reference: 

neighborhoods <- st_read(path(basepath, "raw/Neighborhood Tabulation Areas.geojson"))
neighborhoods <- st_transform(neighborhoods, crs = thecrs)
pryr::object_size(neighborhoods) #1.87 MB
neighborhoods <- rmapshaper::ms_simplify(neighborhoods)
pryr::object_size(neighborhoods) #302 kB
st_geometry(neighborhoods) %>% plot()

neighborhoods <- mutate(neighborhoods,
               shape_area = as.numeric(as.character(shape_area)) * 9.2903e-8,
               shape_leng = as.numeric(as.character(shape_leng)) * 0.0003048)

st_write(neighborhoods, path(basepath, "processed/neighborhoods.gpkg"))
st_write(neighborhoods, path(basepath, "processed/neighborhoods.geojson"))
st_write(neighborhoods, path(basepath, "processed/neighborhoods.shp"))




st_write(boro_bbox, path(basepath, "processed/boroughs_bbox.gpkg"))



# NLCD
# Reference

# careful to delete raw and extractions folder
nlcd <- FedData::get_nlcd(template = raster(boro_bbox),
                  raw.dir = path(basepath, "FedData-downloads/RAW/NLCD"),
                extraction.dir = path(basepath, "FedData-downloads/EXTRACTIONS/NYC_landcover/NLCD"),
                  year = 2011,
                  dataset = "landcover",
                  label = "NYC_landcover")
raster::plot(nlcd)
nlcd <- projectRaster(nlcd, crs = theproj4)
res(nlcd)
ncell(nlcd) #5,461,560
writeRaster(nlcd, path(basepath, "processed/nlcd.grd"), overwrite = TRUE)
writeRaster(nlcd, path(basepath, "processed/nlcd.tif"), overwrite = TRUE)
# can't do this
#nlcd_lowres <- aggregate(nlcd, fact = 4)
#ncell(nlcd_lowres) #341640
#plot(nlcd_lowres)


# Canopy

# careful to delete raw and extractions folder
canopy <- FedData::get_nlcd(template = raster(boro_bbox),
                          raw.dir = path(basepath, "FedData-downloads/RAW/NLCD"),
                          extraction.dir = path(basepath, "FedData-downloads/EXTRACTIONS/NYC_canopy/NLCD"),
                          year = 2011,
                          dataset = "canopy",
                          label = "NYC_canopy")
raster::plot(canopy)
canopy <- projectRaster(canopy, crs = theproj4)
res(canopy)
ncell(canopy) #3,547,552
writeRaster(canopy, path(basepath, "processed/canopy.grd"), overwrite = TRUE)
writeRaster(canopy, path(basepath, "processed/canopy.tif"), overwrite = TRUE)
canopy_lowres <- aggregate(canopy, fact = 10)
ncell(canopy_lowres) #35532
plot(canopy_lowres)
writeRaster(canopy_lowres, path(basepath, "processed/canopy_lowres.grd"), overwrite = TRUE)
writeRaster(canopy_lowres, path(basepath, "processed/canopy_lowres.tif"), overwrite = TRUE)




# Landmarks
# Reference: 

landmarks <- tribble(
  ~location, ~lat, ~long,
  "Gimme! Coffee", 40.722346,-73.997195,
  "Empire State Building", 40.7484405,-73.9878584,
  "Blind Tiger Bar", 40.7318633,-74.0054307
)

landmarks <- st_as_sf(landmarks, coords = c("long", "lat"), crs = 4326, agr = "identity")
st_write(landmarks, path(basepath, "processed/landmarks.gpkg"))
st_write(landmarks, path(basepath, "processed/landmarks.geojson"))
st_write(landmarks, path(basepath, "processed/landmarks.shp"))


landmarks_prj <- st_transform(landmarks, crs = theproj4@projargs)

st_write(landmarks_prj, path(basepath, "processed/landmarks_prj.gpkg"))
st_write(landmarks_prj, path(basepath, "processed/landmarks_prj.geojson"))
st_write(landmarks_prj, path(basepath, "processed/landmarks_prj.shp"))


# Elevation




ned <- FedData::get_ned(template = raster(boro_bbox),
                            raw.dir = path(basepath, "FedData-downloads/RAW/NLCD"),
                            extraction.dir = path(basepath, "FedData-downloads/EXTRACTIONS/NYC_canopy/NLCD"),
                            label = "NYC_elevation")

raster::plot(ned)
ned <- projectRaster(ned, crs = theproj4)
res(ned)
ncell(ned) #3,547,552
writeRaster(ned, path(basepath, "processed/ned.grd"), overwrite = TRUE)
writeRaster(ned, path(basepath, "processed/ned.tif"), overwrite = TRUE)
ned_lowres <- aggregate(ned, fact = 10)
ncell(ned_lowres) #35532
plot(ned_lowres)
writeRaster(ned_lowres, path(basepath, "processed/ned_lowres.grd"), overwrite = TRUE)
writeRaster(ned_lowres, path(basepath, "processed/ned_lowres.tif"), overwrite = TRUE)


manhattan <- brick("/Volumes/GoogleDrive/My Drive/projects/workshop-r-spatial-slides/big-project-files/gis-data/nyc/raw/rasters/manhattan.tif")
manhattan <- aggregate(manhattan, fact = 4)
writeRaster(manhattan, path(basepath, "processed/manhattan_lowres.tif"), overwrite = TRUE)



a = st_sf(a = 1:2, geom = st_sfc(st_point(c(-76.440496, 42.448701)), st_point(c(-76.346582, 42.385607))), crs = 4326) # 30sodom
a = st_sf(a = 1:2, geom = st_sfc(st_point(c(-76.52695, 42.41832)), st_point(c(-76.46980, 42.46708))), crs = 4326)
a <- st_transform(a, crs = 26919)
box1 <- st_as_sfc(st_bbox(a))






ned <- FedData::get_ned(template = as(box1, "Spatial"),label = "ith_elevation")


# Pluto
# https://www1.nyc.gov/site/planning/data-maps/open-data/dwn-pluto-mappluto.page
# https://www1.nyc.gov/assets/planning/download/pdf/data-maps/open-data/meta_mappluto.pdf?r=18v21beta
# I dragged gdb folder to QGIS to see layer name
pluto <- st_read(path(basepath, "raw/nyc_mappluto_18v2_1_fgdb/MapPLUTO_18v2_1.gdb"), 
             layer = "MapPLUTO_18v2_1_Shoreline_Clipped" )


pl1850 <- filter(pluto, !is.na(YearBuilt), YearBuilt<1850, YearBuilt>1700)
pl10plusfloors <- filter(pluto, !is.na(NumFloors), NumFloors>=10)
#pIndustry <- filter(pluto, !is.na(BldgClass), stringr::str_sub(BldgClass, 1,1) == "F")
pHotels <- filter(pluto, !is.na(BldgClass), stringr::str_sub(BldgClass, 1,1) == "H")
pTheaters <- filter(pluto, !is.na(BldgClass), stringr::str_sub(BldgClass, 1,1) == "J")
pLUindustry <- pTheaters <- filter(pluto, !is.na(LandUse), LandUse  == "06")


st_write(pl1850, path(basepath, "processed/pluto_pre_1850.gpkg"))
st_write(pl10plusfloors, path(basepath, "processed/pluto_10floors_ormore.gpkg"))
st_write(pHotels, path(basepath, "processed/pluto_hotels.gpkg"))
st_write(pTheaters, path(basepath, "processed/pluto_theaters.gpkg"))
st_write(pLUindustry, path(basepath, "processed/pluto_landuse_industrial.gpkg"))


# POINTS OF INTEREST

poi <- st_read("/Volumes/GoogleDrive/My Drive/projects/workshop-r-spatial-slides/big-project-files/gis-data/nyc/raw/Points Of Interest/geo_export_bd28e41b-d6be-464b-b24a-1dd40fca9ec3.shp")
poi <- st_transform(poi, crs = 2908)
poi <- select(poi, faci_dom, facility_t, name)
st_write(poi , path(basepath, "processed/poi.gpkg"))



# Roads

#https://data-usdot.opendata.arcgis.com/datasets/highway-performance-monitoring-system-fsys-123/data
#library(tigris)
#roads <- tigris::primary_roads("New York", c("005"))

# https://data.cityofnewyork.us/City-Government/NYC-Street-Centerline-CSCL-/exjm-f27b

#https://www.fhwa.dot.gov/policyinformation/hpms/shapefiles.cfm

road_ny <- st_read(path(basepath, "raw/newyork2017/NewYork2017.shp"))
road_ny <- st_transform(road_ny, crs = st_crs(boro))
road_ny <- st_zm(road_ny)
roads_nyc <- st_intersection(road_ny, boro)
st_write(roads_nyc, path(basepath, "processed/roads_nyc_hpms2017.shp"))

# Census

counties <- c("New York County", "Kings County", "Bronx County", "Queens County", "Richmond County")   


# get total population: B01003  from 2017 acs 5yr 

#by block group
pop_bg <- get_acs(geography = "block group", table = "B01003", year = 2017, state="NY", 
                  county = counties, geometry  = TRUE, output = "wide", cache_table=TRUE)

#by census tract
pop_tract <- get_acs(geography = "tract", table = "B01003",year = 2017, state="NY", 
                     county = counties, geometry  = TRUE, output = "wide", cache_table=TRUE)



st_write(pop_bg, path(basepath, "processed/pop2017_block_group.shp"))
st_write(pop_tract, path(basepath, "processed/pop2017_tract.shp"))




# San Francisco



basepath <- "/Volumes/GoogleDrive/My Drive/projects/workshop-r-spatial-slides/big-project-files/gis-data/sf/"
thecrs <- 2908
theproj4 <- CRS(glue::glue("+init=epsg:{thecrs}"))
wgs84 <- CRS("+init=epsg:4236")



# california counties
library(tigris)
library(fs)
library(sf)
library(raster)
library(tmap)
basepath <- '/Volumes/GoogleDrive/My Drive/projects/workshop-r-spatial-slides/big-project-files/gis-data/sf/'
tigris_cache_dir('/Volumes/GoogleDrive/My Drive/projects/workshop-r-spatial-slides/big-project-files/gis-data/sf/')
options(tigris_class = "sf")
ca <- tigris::counties(state = "ca", resolution = "20m")
st_write(ca, path(basepath, "raw/ca_counties_20m.gpkg"))

ca_simp <- rmapshaper::ms_simplify(ca)
st_write(ca_simp, path(basepath, "processed/ca_counties_20m_simplified.shp"))

ca <- read_sf(path(basepath, "raw/ca_counties_20m.gpkg"))


# SF
basepath <- "/Volumes/GoogleDrive/My Drive/projects/workshop-r-spatial-slides/big-project-files/gis-data/sf/"
sf_roads <- read_sf(path(basepath, "raw/Streets - Active and Retired.geojson"))
sf_roads <- filter(sf_roads, active == "true")

filter(sf_roads, st_type == "BLVD") %>% 
  qtm()
rd <- primary_roads(class = "sf")
st_write(rd, "/Volumes/GoogleDrive/My Drive/projects/workshop-r-spatial-slides/big-project-files/gis-data/usa/primary_roads.gpkg")


ca <- st_transform(ca, crs = st_crs(rd))
x <- st_touches(rd, ca)
x2 <- purrr::map_lgl(x, ~length(.)>0)
x3 <- rd[x2,]

rd <- roads(state = "ca", county = "san francisco", class = "sf")
st_write(rd, "/Volumes/GoogleDrive/My Drive/projects/workshop-r-spatial-slides/big-project-files/gis-data/sf/raw/tigris_roads.gpkg")


parks <- read_sf("/Volumes/GoogleDrive/My Drive/projects/workshop-r-spatial-slides/big-project-files/gis-data/sf/raw/Park Lands - Recreation and Parks Department.geojson")
parks <- mutate(parks,
                x = as.numeric(x),
                y = as.numeric(y),
                sqft = as.numeric(sqft),
                acres = as.numeric(acres)) %>% 
  filter(x<(-120))

st_write(parks, "/Volumes/GoogleDrive/My Drive/projects/workshop-r-spatial-slides/big-project-files/gis-data/sf/processed/parks.gpkg")

#https://data.sfgov.org/Geographic-Locations-and-Boundaries/Building-Footprints/ynuv-fyni
footprints <- st_read("/Volumes/GoogleDrive/My Drive/projects/workshop-r-spatial-slides/big-project-files/gis-data/sf/raw/Building Footprints/geo_export_573c6470-95be-4dc2-83c6-fb5113ff4450.shp")
footprints <- st_transform(footprints, crs = 7131)
# 100 feet
footprints100ft <- filter(footprints, hgt_maxcm >= 3048)

footprints200ft <- filter(footprints, hgt_maxcm >= 6096)

footprints500ft <- filter(footprints, hgt_maxcm >= 15240)

st_write(footprints500ft, "/Volumes/GoogleDrive/My Drive/projects/workshop-r-spatial-slides/big-project-files/gis-data/sf/processed/footprints500ft.gpkg")


f <- function(.data){
  res <- st_intersects(.data, mission)
  sparse <- purrr::map_lgl(res, ~length(.)>0)
  .data[sparse,]
}

basepath <- "/Volumes/GoogleDrive/My Drive/projects/workshop-r-spatial-slides/big-project-files/gis-data/sf/processed/mission"

neigh <- read_sf("/Volumes/GoogleDrive/My Drive/projects/workshop-r-spatial-slides/big-project-files/gis-data/sf/raw/SF Find Neighborhoods/geo_export_44084b71-6c29-4216-9396-8753c283e08b.shp")
neigh <- st_transform(neigh, crs = 7131)
mission <- filter(neigh, name == "Mission")
rd <- st_transform(rd, crs = 7131)

mission_buf <- st_buffer(mission, 1312.34)

rd_over <- st_intersects(rd, mission)
rd_true <- purrr::map_lgl(rd_over, ~length(.)>0)
rd_mission <- rd[rd_true,]

rd400 <- st_crop(rd, mission_buf)
rd <- st_crop(rd, mission)

tm_shape(rd_mission) + tm_lines() + tm_shape(mission) + tm_borders(col = "yellow")
st_write(rd, path(basepath, "roads-mission.shp"))
st_write(rd400, fs::path(basepath, "roads-mission-400mbuf.shp"))
st_write(rd_mission, path(basepath, "roads-mission-fulllength.shp"))
st_write(mission, "/Volumes/GoogleDrive/My Drive/projects/workshop-r-spatial-slides/big-project-files/gis-data/sf/processed/mission/boundary-mission.gpkg")

parks <- read_sf("/Volumes/GoogleDrive/My Drive/projects/workshop-r-spatial-slides/big-project-files/gis-data/sf/processed/parks.gpkg")
parks <- st_transform(parks, crs = 7131)
park_over <- st_intersects(parks, mission)
parks2 <- f(parks, park_over)
tm_shape(parks2) + tm_polygons() + tm_shape(mission, is.master = TRUE) + tm_borders(col = "red")
st_write(parks2, path(basepath, "mission_parks.shp")) 


footprints <- st_read("/Volumes/GoogleDrive/My Drive/projects/workshop-r-spatial-slides/big-project-files/gis-data/sf/raw/Building Footprints/geo_export_573c6470-95be-4dc2-83c6-fb5113ff4450.shp")
footprints <- st_transform(footprints, crs = 7131)
footprints_mission <- f(footprints)
tm_shape(footprints_mission) + tm_polygons() + tm_shape(mission, is.master = TRUE) + tm_borders(col = "red")
footprints_mission <- select(footprints_mission, globalid, hgt_maxcm)

#footprints500ft <- filter(footprints, hgt_maxcm >= 15240)
st_write(footprints_mission, fs::path(basepath, "footprints-mission.gpkg"))

zoning <- read_sf("/Volumes/GoogleDrive/My Drive/projects/workshop-r-spatial-slides/big-project-files/gis-data/sf/raw/Zoning Map - Zoning Districts/geo_export_a66aac4a-1fbe-4fb3-b57c-f54b03472d96.shp")
zoning <- st_transform(zoning, crs = 7131)
zoning <- lwgeom::st_make_valid(zoning)
zoning_mission <- st_crop(zoning, mission)

zoning_mission <- mutate(zoning_mission,
                         zonecode = forcats::fct_recode(gen,
                                                   "1" = "Public",
                                                   "2" = "Residential",
                                                   "3" = "Mixed Use",
                                                   "4" = "Industrial"
                 )
) %>% 
  mutate(zonecode = as.numeric(zonecode))


#zoning_mission <- f(zoning)
tm_shape(zoning_mission) + tm_polygons("gen") + tm_shape(mission, is.master = TRUE) + tm_borders(col = "red")
tm_shape(zoning_mission) + tm_polygons("zonecode") + tm_shape(mission, is.master = TRUE) + tm_borders(col = "red")
st_write(zoning_mission, fs::path(basepath, "processed/zoning-mission.shp"))


slopes <- st_read("/Volumes/GoogleDrive/My Drive/projects/workshop-r-spatial-slides/big-project-files/gis-data/sf/raw/Slopes of 20% Or Greater/geo_export_e9e11ed6-0749-4b59-87c2-7045dced449f.shp")
slopes <- st_transform(slopes, crs = 7131)
slopes_mission <- f(slopes)
tm_shape(slopes_mission) + tm_polygons() + tm_shape(mission, is.master = TRUE) + tm_borders(col = "red")
st_write(slopes_mission, path(basepath, "mission_slopes.shp"))



ned <- FedData::get_ned(template = raster(mission),
                        raw.dir = path(basepath, "FedData-downloads/RAW/NLCD"),
                        extraction.dir = path(basepath, "FedData-downloads/EXTRACTIONS/NYC_canopy/NLCD"),
                        label = "mission_elevation")

ned <- projectRaster(ned, crs = st_crs(slopes)$proj4string)
tm_shape(ned) + tm_raster() + 
  tm_shape(mission, is.master = TRUE) + tm_borders(col = "red")+
  tm_shape(slopes_mission) + tm_borders()
writeRaster(ned, path(basepath, "mission_ned.tif"))

plot(ned)
contours <- rasterToContour(ned)
contours <- as(contours, "sf")
contours <- mutate(contours,
                   level = as.numeric(as.character(level))) %>% 
  filter(level>0)
st_write(contours, path(basepath, "contours_sanfrancisco.shp"))


plot(ned)
plot(filter(contours, level>0), add = TRUE)



bay_area <- read_sf("/Volumes/GoogleDrive/My Drive/projects/workshop-r-spatial-slides/big-project-files/gis-data/sf/raw/Bay Area Counties/geo_export_7b9a6af8-e1c3-41be-95f3-083775309f89.shp")
#bay_area <- st_transform(bay_area, crs = "+proj=utm +zone=10 +datum=WGS84 +units=m +no_defs +ellps=WGS84 +towgs84=0,0,0")

st_write(bay_area, fs::path(basepath, "/counties-bayarea.gpkg"))
st_write(bay_area, fs::path(basepath, "/counties-bayarea.shp"))

"+proj=utm +zone=10 +datum=WGS84 +units=m +no_defs +ellps=WGS84 +towgs84=0,0,0"
#https://data.sfgov.org/Geographic-Locations-and-Boundaries/Bay-Area-Counties/s9wg-vcph
#ca_counties <- tigris::counties("ca", class = "sf")
#ca_counties <- read_sf("/Volumes/GoogleDrive/My Drive/projects/workshop-r-spatial-slides/big-project-files/gis-data/sf/processed/ca_counties_20m_simplified.shp")
sf_outline <- filter(bay_area , county == "San Francisco")
sf_outline <- st_cast(sf_outline, "POLYGON") 
sf_outline <-  mutate(sf_outline, area = units::drop_units(st_area(sf_outline)))
sf_outline <- filter(sf_outline, area == max(sf_outline$area))
sf_outline <- st_transform(sf_outline, crs = 7131)
st_write(sf_outline, path(basepath, "/processed/sanfran_county.gpkg"))

ned <- FedData::get_ned(template = raster(sf_outline),
                        raw.dir = path(basepath, "FedData-downloads/RAW/NLCD"),
                        extraction.dir = path(basepath, "FedData-downloads/EXTRACTIONS/NYC_canopy/NLCD"),
                        label = "sf_elevation")

ned <- projectRaster(ned, crs = st_crs(sf_outline)$proj4string)
tm_shape(ned) + tm_raster() + 
  tm_shape(sf_outline, is.master = TRUE) + tm_borders(col = "red")+
  tm_shape(slopes_mission) + tm_borders()
writeRaster(ned, path(basepath, "/processed/elevation-sanfrancisco.tif"))




#http://www.prism.oregonstate.edu/normals/
bil <- raster::raster("/Volumes/GoogleDrive/My Drive/projects/workshop-r-spatial-slides/big-project-files/gis-data/usa/PRISM_ppt_30yr_normal_800mM2_annual_bil/PRISM_ppt_30yr_normal_800mM2_annual_bil.bil")
sf_outline <- st_transform(sf_outline, crs = 4326)

bay_area2 <- filter(bay_area, county%in%c("Alameda", "Contra Costa", "Marin", "San Francisco", "San Mateo"))
precip <- raster::crop(bil, bay_area )
plot(precip)
plot(st_geometry(sf_outline), add = TRUE)
precip2 <- disaggregate(precip, fact = 2, method = "bilinear")
x <- crop(precip2, sf_outline)
writeRaster(precip2, "/Volumes/GoogleDrive/My Drive/projects/workshop-r-spatial-slides/big-project-files/gis-data/sf/processed/precip-bayarea-disag.tif")


basepath <- "/Volumes/GoogleDrive/My Drive/projects/workshop-r-spatial-slides/big-project-files/gis-data/sf/processed"
sf_neigh <- read_sf("/Volumes/GoogleDrive/My Drive/projects/workshop-r-spatial-slides/big-project-files/gis-data/sf/raw/SF Find Neighborhoods/geo_export_44084b71-6c29-4216-9396-8753c283e08b.shp")
sf_neigh <- st_transform(sf_neigh, crs = 7131)
st_write(sf_neigh, fs::path(basepath, "neighborhoods-sanfrancisco.gpkg"))


x <- brick("/Volumes/GoogleDrive/My Drive/projects/workshop-r-spatial-slides/big-project-files/gis-data/sf/raw/rasters/CA/2015/201502_san_francisco_ca_0x3000m_utm_cnir/vol005/10seg505790.tif")

tm_shape(x) + tm_rgb() + 
  tm_shape(mission, is.master = TRUE) + tm_borders(col = "red")

mission <- st_transform(mission, crs = crs(x))
plotRGB(x)
plot(st_geometry(mission), add = TRUE, border = "yellow")



#https://aqs.epa.gov/aqsweb/airdata/annual_conc_by_monitor_2018.zip
#
library(yelpr)
dat <- business_search(
  api_key = "csw12owoEQ2DpjIM2gZsCaM7MEHRPNKXBU1s72gUvChKO3Kj88EzwgI2GE2PaAjKGo791x2ew8ssrfScFPKcLAUHwSSxgzW7JZMJH6EOkC2T9BFuMg4tKWScBU0JXXYx",
  latitude = 37.7599043,
  longitude = -122.425623,
  term = "burritos",
  limit = 50)

dat <- dat$businesses
burritos <- tibble(
  name = dat$name,
  review_count = dat$review_count,
  rating = dat$rating,
  lat = dat$coordinates$latitude,
  long = dat$coordinates$longitude,
  distance = dat$distance,
  address = dat$location$address1
)

burritos <- st_as_sf(burritos, coords = c("long", "lat"), crs = 4326, agr = "identity")
burritos <- st_transform(burritos, crs = 7131)
st_write(burritos, path(basepath, "burritos.gpkg"))
tm_shape(mission, is.master = TRUE) + tm_borders(col = "red") +
  tm_shape(burritos) + tm_dots("review_count", size = 1)

glimpse(dat)


# landsat 8

#https://www.esa.int/ESA_Multimedia/Images/2015/06/San_Francisco_Bay_Area_USA


# landsat

#https://www.earthdatascience.org/courses/earth-analytics/multispectral-remote-sensing-data/landsat-data-in-r-geotiff/
mission2 <- st_transform(mission, crs = crs(br)@projargs)

x <- crop(br, mission2)
y <- mask(x, mission2)

plot(br, col = gray(0:100 / 100))


all_landsat_bands <- list.files("/Volumes/GoogleDrive/My Drive/projects/workshop-r-spatial-slides/big-project-files/gis-data/sf/raw/rasters/LC080440342019050301T1-SC20190613150846/",
                                pattern = glob2rx("*band*.tif$"),
                                full.names = TRUE) 

ls_stack <- stack(all_landsat_bands[2:4])
ls_brick <- brick(ls_stack)
mission2 <- st_transform(mission, crs = crs(ls_brick)@projargs)
plotRGB(ls_brick, r = 4, g = 3, b = 2, stretch = "lin", axes = TRUE)
# more of marin st_point(c(-122.672639, 37.881916)
# tighter northern point 37.807572, -122.536699
#37.712077, -122.308143 sf bay
# bigger portion of sf st_point(c(-122.135669, 37.525884)
#37.831428, -122.555287
#37.674655, -122.332193
a = st_sf(a = 1:2, geom = st_sfc(st_point(c(-122.555287, 37.831428)), st_point(c(-122.332193, 37.674655))), crs = 4326) 
a <- st_transform(a, crs = crs(ls_brick)@projargs)
box1 <- st_as_sfc(st_bbox(a)) %>% 
  st_sf()

x <- crop(ls_brick, box1)
y <- mask(x, box1)
plotRGB(y, r = 4, g = 3, b = 2, stretch = "lin", axes = TRUE)

y2 <- projectRaster(y, crs = st_crs(mission)$proj4string)
plotRGB(y2, r = 3, g = 2, b = 1, stretch = "lin", axes = TRUE)
writeRaster(y2, path(basepath, "sf_landsat.tif"))

x2 <- brick("/Volumes/GoogleDrive/My Drive/projects/workshop-r-spatial-slides/big-project-files/gis-data/final/data/san-francisco/sf_landsat.tif")

x <- st_read("/Volumes/GoogleDrive/My Drive/projects/workshop-r-spatial-slides/big-project-files/gis-data/sf/processed/ca_counties_20m_simplified.shp")
st_write(x, "/Volumes/GoogleDrive/My Drive/projects/workshop-r-spatial-slides/big-project-files/gis-data/final/san-francisco/california-counties.shp")

filter(x, name == "San Francisco")

# dat <- dat$businesses
# st_write(dat, path(basepath, "processed/sf_mexican_restaurants.shp"))
# 
# 
# dat <- business_search(
#   api_key = "csw12owoEQ2DpjIM2gZsCaM7MEHRPNKXBU1s72gUvChKO3Kj88EzwgI2GE2PaAjKGo791x2ew8ssrfScFPKcLAUHwSSxgzW7JZMJH6EOkC2T9BFuMg4tKWScBU0JXXYx",
#   location = "London",
#   term = "indian restaurant",
#   limit = 50)


# options(noaakey = "KRUUvBLqGBUOHpLWUOeAPnpZaGlxasgW")
# library(rnoaa)
# sf_sites <- ncdc_locs(locationcategoryid='CITY', sortfield='name', sortorder='desc')
# x <-ncdc_locs(datasetid='GHCND'
# View(sf_sites$data)
# 
# library(sf)
# x <- read_sf("/Volumes/GoogleDrive/My Drive/projects/workshop-r-spatial-slides/big-project-files/gis-data/sf/raw/Building Footprints.geojson")
# library(gdalUtils)
#path(basepath, "raw/rasters/centralpark.jp2")
#gdal_translate("/Volumes/GoogleDrive/My Drive/projects/workshop-r-spatial-slides/big-project-files/gis-data/nyc/raw/rasters/centralpark.jp2", "/Volumes/GoogleDrive/My Drive/projects/workshop-r-spatial-slides/big-project-files/gis-data/nyc/raw/rasters/centralpark.tif")
#/Volumes/GoogleDrive/My Drive/projects/workshop-r-spatial-slides/big-project-files/gis-data/nyc/raw/rasters/centralpark.jp2

# Precipitation

# library(sf)
# bboxwgs84 <- st_transform(boro_bbox, crs = 26918)
# box <- polygon_from_extent(extent(bboxwgs84), proj4string = st_crs(bboxwgs84)$proj4string)
# 
# 
# daymet <- FedData::get_daymet(template = box,
#                             raw.dir = path(basepath, "FedData-downloads/RAW/daymet"),
#                             extraction.dir = path(basepath, "FedData-downloads/EXTRACTIONS/NYC_tmax/daymet"),
#                             year = 2017,
#                             elements = "tmax",
#                             label = "NYC_tmax")
# 
# vepPolygon <- polygon_from_extent(raster::extent(672800, 740000, 4102000, 4170000),
#                                   proj4string = "+proj=utm +datum=NAD83 +zone=12")
# 
# DAYMET <- get_daymet(template = vepPolygon,
#                      label = "VEPIIN",
#                      elements = c("prcp","tmax"),
#                      years = 1980)
# 
# 
# gisdata_path <- "/Volumes/GoogleDrive/My Drive/projects/workshop-r-spatial-slides/big-project-files/gis-data/"
# 
# london_wards_online <- "https://data.london.gov.uk/download/statistical-gis-boundary-files-london/08d31995-dd27-423c-a987-57fe8e952990/London-wards-2018.zip"
# london_wards_disk <- fs::path(gisdata_path, "/london/London-wards-2018.zip")
# curl::curl_download(london_wards_online, london_wards_disk)
# unzip(london_wards_disk, exdir = gisdata_path)
# 
# london <- sf::st_read(fs::path(gisdata_path, "london/London-wards-2018_ESRI/London_Ward.shp"))
# london_city <- filter(london, DISTRICT == "City and County of the City of London")
# 
# sf::st_write(london_city, "/Users/zevross/git-repos/workshop-r-spatial-slides/data/london.gpkg")
# 
# 
# # Neighborhoods
# 
# #https://data.cityofnewyork.us/City-Government/Neighborhood-Tabulation-Areas/cpf4-rkhq
# #https://data.cityofnewyork.us/Education/School-Point-Locations/jfju-ynrr
# #https://data.nysed.gov/downloads.php
# 
# boro <- sf::st_read("/Volumes/GoogleDrive/My Drive/projects/workshop-r-spatial-slides/big-project-files/gis-data/nyc/Borough Boundaries/geo_export_15cbe885-e27c-428a-8433-0ee4112a868a.shp")
# boro <- st_transform(boro, crs = 2908)
# 
# boro <- st_buffer(boro, 3280.84)
# boro_bbox <- st_bbox(boro)
# boro_bbox <- st_as_sfc(st_bbox(boro_bbox)) %>% 
#   st_sf()
# 
# st_write(boro, "/Volumes/GoogleDrive/My Drive/projects/workshop-r-spatial-slides/big-project-files/gis-data/nyc/processed/boro1kmbuffer.gpkg")
#   
# boro_bbox <- as(boro_bbox, "Spatial")
# 
# 
# rand_raster <- raster(boro_bbox, nrow=10, ncol = 10, vals = rnorm(100)) 
# writeRaster(rand_raster, "/Volumes/GoogleDrive/My Drive/projects/workshop-r-spatial-slides/big-project-files/gis-data/nyc/processed/rand_raster.grd")
# 
# NLCD <- FedData::get_nlcd(template = boro_bbox,
#                  year = 2011,
#                  dataset = "landcover",
#                  label = "NYCy")
# raster::plot(NLCD)
# 
# writeRaster(NLCD, "/Volumes/GoogleDrive/My Drive/projects/workshop-r-spatial-slides/big-project-files/gis-data/nyc/processed/NLCD2011.tif")
# 
# 
# NLCD <- FedData::get_nlcd(template = boro_bbox,
#                           year = 2011,
#                           dataset = "canopy",
#                           label = "NYC canopy")
# raster::plot(NLCD)
# NLCD <- projectRaster(NLCD, crs = st_crs(boro_bbox)$proj4string)
# 
# writeRaster(NLCD, "/Volumes/GoogleDrive/My Drive/projects/workshop-r-spatial-slides/big-project-files/gis-data/nyc/processed/canopy2011.tif", overwrite = TRUE)
# neigh <- st_read("/Volumes/GoogleDrive/My Drive/projects/workshop-r-spatial-slides/big-project-files/gis-data/nyc/raw/Neighborhood Tabulation Areas.geojson")
# soho <- filter(neigh, ntaname == "New Brighton-Silver Lake")
# 
# soho_nlcd <- crop(NLCD, soho)
# 
# 
# 
# vepPolygon <- polygon_from_extent(raster::extent(672800,740000,4102000,4170000), 
#                                   proj4string='+proj=utm +datum=NAD83 +zone=12')
# 
# # Get the NLCD (USA ONLY)
# # Returns a raster
# NLCD <- get_nlcd(template=vepPolygon, label='VEPIIN')


# SF
# https://data.sfgov.org/Geographic-Locations-and-Boundaries/Zoning-Map-Zoning-Districts/xvjh-uu28
#https://data.sfgov.org/Geographic-Locations-and-Boundaries/Building-Footprints/ynuv-fyni

poly1 <- st_polygon(list(rbind(c(0,0), c(1,0), c(3,2), c(2,4), c(1,4), c(0,0)))) %>% st_sfc() %>% st_sf()
poly2 <- st_polygon(list(rbind(c(1,1), c(1,2), c(2,2), c(1,1)))) %>% st_sfc() %>% st_sf()
polygons <- rbind(poly1, poly2)
polygons$id <- 1:2



line1 <- st_linestring(rbind(c(0, 0), c(1.5, 1))) %>% st_sfc() %>% st_sf()
line2 <- st_linestring(rbind(c(1, 0), c(1,0.5))) %>% st_sfc() %>% st_sf()
lines <- rbind(line1, line2)
lines$id <- 1:2


plot(polygons, axes = TRUE)
plot(line1, add = TRUE, col = "red")
plot(line2, add = TRUE, col = "red")

tm_shape(polygons) + tm_polygons("id", style = "cat", pal = "Dark2") + 
  tm_shape(lines, is.master = TRUE) + tm_lines("id", style = "cat", pal = "Set1", lwd = 3)

point
