http://bit.ly/zrsaSpatialWorkshop

# To get to dashboard

* Log in as Zev, replace workspace with "admin" in URL

# Creation of server

```bash
sudo add-apt-repository 'deb https://cloud.r-project.org/bin/linux/ubuntu bionic-cran35/'
sudo apt-key adv --keyserver keyserver.ubuntu.com --recv-keys E298A3A825C0D65DFD57CBB651716619E084DAB9
sudo apt-get update
sudo apt-get install r-base

sudo apt-get install gdebi-core
wget https://download2.rstudio.org/server/bionic/amd64/rstudio-server-1.2.5033-amd64.deb
sudo gdebi rstudio-server-1.2.5033-amd64.deb

# units package requires libdunits2-dev
sudo add-apt-repository ppa:ubuntugis/ppa
sudo apt-get update
sudo apt-get install libudunits2-dev libgdal-dev libgeos-dev libproj-dev
sudo apt install libcurl4-openssl-dev libssl-dev libxml2-dev


# BEGIN if you installed old version of R and need to remove
sudo R
.libPaths() # to find where the packages were
sudo apt-get purge --auto-remove r-base
# then manually remove the folders from .libPaths()
sudo apt-get install r-base
# END if you need to remove

# https://github.com/mtennekes/tmap/blob/master/ubuntu_17_installation.sh
sudo apt-get install libv8-dev 
sudo apt-get install libjq-dev 
sudo apt-get install libprotobuf-dev 
sudo apt-get install protobuf-compiler
sudo apt-get install libcairo2-dev

# this only really for OpenStreetMap
sudo apt-get install -y default-jre
sudo apt-get install -y default-jdk
sudo R CMD javareconf

# then

sudo R
install.packages("sf")
install.packages("tmap")
install.packages(c("mapview", "raster"))
install.packages(c("ggplot2", "tidyr", "dplyr", "stringr"))
install.packages("rmapshaper")
install.packages("rJava")
install.packages("shinyjs") # for tmaptools::palette_explorer()
install.packages("OpenStreetMap") # for tmaptools::read_osm()
install.packages(c(“tidycensus”, “FedData”, “osmdata”,  “rnaturalearth”)) 

mkdir uploads
chmod -R 755 uploads
chown ubuntu uploads

```



# This is the repo for the exercise/solutions package

```bash
# On your machine
scpspatialworkshop  ~/git-repos/zrsaSpatialWorkshop_0.2.tar.gz
scpspatialworkshop ~/git-repos/workshop-r-spatial-slides/pdfs/Archive.zip 

```

```bash
unzip Archive.zip
# On the server
sudo R
detach(package:zrsaSpatialWorkshop) # error related to name is fine
remove.packages("zrsaSpatialWorkshop")
q()
sudo R

# careful what folder
install.packages('/home/ubuntu/uploads/zrsaSpatialWorkshop_0.2.tar.gz',
  repos = NULL, type="source")
```

# Delete existing users


```bash
sudo rstudio-server kill-all
sudo rstudio-server restart

 for i in {1001..1200}
  do
    sudo userdel -r guest$i
done
```

# Delete slides then unzip

```bash
cd ~/uploads # not under sudo su
sudo rm -rf -d *.pdf
unzip datascienceRworkshop1_slides.zip
chmod -R 755 ~/uploads
```




# If you just want to delete slides from user folders

```bash
# delete slides
for i in {1001..1100}
  do
    echo $i
    user=guest$i
    sudo -u $user rm -rf -d /home/$user/slides/*pdf
done

# delete data
for i in {1001..1100}
  do
    echo $i
    user=guest$i
    sudo -u $user rm -rf -d /home/$user/data/*.*
done

```



## Create users and folders

```bash
for i in {1001..1100}
  do
    echo $i
    echo "guest$i:pass$i:$i:800:RStudio:/home/guest$i:/bin/bash" | sudo newusers
    user=guest$i
    sudo -u $user mkdir -p /home/$user/slides
    sudo -u $user mkdir -p /home/$user/data
    sudo -u $user mkdir -p /home/$user/workshop-package
done
```

## Copy materials to users

```bash
for i in {1001..1100}
  do
    echo $i
    user=guest$i
    sudo -u $user cp -a /home/ubuntu/uploads/*.pdf /home/$user/slides/
    sudo -u $user cp -a /usr/local/lib/R/site-library/zrsaSpatialWorkshop/data-raw/* /home/$user/data/
    sudo -u $user cp -a /home/ubuntu/uploads/zrsaSpatialWorkshop_0.2.tar.gz /home/$user/workshop-package/
done


# just for package updates
for i in {1001..1100}
  do
    echo $i
    user=guest$i
    sudo -u $user cp -a /home/ubuntu/uploads/zrsaSpatialWorkshop_0.2.tar.gz /home/$user/workshop-package/
done


# if you only want to move data
for i in {1001..1100}
  do
    echo $i
    user=guest$i
    sudo -u $user cp -a /usr/local/lib/R/site-library/zrsaSpatialWorkshop/data-raw/* /home/$user/data/
done
```




## Fixing a broken session

If a user is experiencing trouble with their session try the following,

1. Connect to the server, `ssh -i path/to/file.pem ubuntu@ec2-107-21-97-192.compute-1.amazonaws.com`
1. Move to the users folder, `cd ~/../user####/`
1. Move their .rstudio folder, `mv .rstudio .rstudio-old`
1. Have the user open a new browser tab or window and connect to the RStudio server

If the problem persists,

1. Connect to the server, if not still connected
1. Find the PID of the users session, `sudo rstudio-server active-sessions | grep user#### | cut -d " " -f 3`
1. Kill or suspend the user's session, `sudo rstudio-server force-suspend-session <PID>` or `sudo kill <PID>`


## Here's what was used for first time teaching
But on my local machine 1/12/2020, I have GEOS 3.7.2, GDAL 2.4.2, PROJ 5.2.0

![image](https://user-images.githubusercontent.com/1395177/72225693-5489d480-3556-11ea-997a-9eb2bbea1b6c.png)

On the Ubuntu (18) machine in prep for the RStudio workshop
![image](https://user-images.githubusercontent.com/1395177/72639498-b28e3180-3933-11ea-971d-b8bff9b06841.png)



